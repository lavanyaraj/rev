package com.niit.shopingcart.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.ShoppingCart.dao.UserDAO;
import com.niit.ShoppingCart.model.User;

@Controller
public class HomeController {
	@RequestMapping("/aboutus")
	public String showabboutus()
	{
		return "aboutus";
	}
	
	@RequestMapping("/upload")
	public String showuploadimage()
	{
		return "upload";
	}
	
}
