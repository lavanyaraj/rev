package com.niit.shopingcart.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.ShoppingCart.dao.CartDAO;
import com.niit.ShoppingCart.dao.ProductDAO;
import com.niit.ShoppingCart.model.Cart;
import com.niit.ShoppingCart.model.Product;
import com.niit.ShoppingCart.model.User;

@Controller
public class CartController {
	
	@Autowired
	private CartDAO cartDAO;
	@Autowired
	private ProductDAO productDAO;
	
	@RequestMapping(value="/myCart", method= RequestMethod.GET)
	public String listCart(Model model){
		model.addAttribute("cart", new Cart());
		model.addAttribute("user", new User());
		model.addAttribute("product",new Product());
		model.addAttribute("productList", this.productDAO.list());
		model.addAttribute("cartList", this.cartDAO.list());
		return "mycart";
		
	}
	
	@RequestMapping(value ="/cartlist/add/{id}", method=RequestMethod.GET)
	public String addToCart(@PathVariable("id") String id, HttpSession session){
		Product product= productDAO.get(id);
		System.out.println("inside");
		Cart cart=new Cart();
		cart.setPrice(product.getPrice());
		cart.setProductName(product.getName());
		cart.setQuantity(1);
		cart.setStatus('N');
		cartDAO.saveorUpdate(cart);
		//return "redirect:views/home.jsp";
		return "redirect:/cart";
	}
		
	@RequestMapping("cart/remove/{id}")
    public String removeCart(@PathVariable("id") String id,ModelMap model) throws Exception{
		
       try {
		cartDAO.delete(id);
		model.addAttribute("message","Successfully removed");
	} catch (Exception e) {
		model.addAttribute("message",e.getMessage());
		e.printStackTrace();
	}
       //redirectAttrs.addFlashAttribute(arg0, arg1)
        return "redirect:/cart";
    }
 
    @RequestMapping("cart/edit/{id}")
    public String editCart(@PathVariable("id") String id, Model model){
    	System.out.println("editCart");
        model.addAttribute("cart", this.cartDAO.get(id));
        model.addAttribute("listCarts", this.cartDAO.list());
        return "cart";
    }
	}


