package com.books.shoppingcart.dao;

import java.util.List;

import com.books.shoppingcart.model.Category;



public interface CategoryDAO {
	
	public List<Category> list();
	public Category get(String id);
	public void saveorUpdate(Category category);
	public Category getByName(String name);
	
	public void delete(String id);
	
}
