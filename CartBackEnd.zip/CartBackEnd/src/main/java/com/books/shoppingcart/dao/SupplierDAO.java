package com.books.shoppingcart.dao;

import java.util.List;
import com.books.shoppingcart.model.Supplier;

public interface SupplierDAO {
	public List<Supplier> list();
	public Supplier get(String id);
	public void saveorUpdate(Supplier supplier);
	public Supplier getByName(String name);
	
	public void delete(String id);
	
}

