package com.books.shoppingcart.dao;

import java.util.List;

import com.books.shoppingcart.model.Cart;

public interface CartDAO {
	
	public List<Cart> list();
	public Cart get(int id);
	public void saveOrUpdate(Cart Cart);
	public String delete(String id);
	public Long getTotalAmount(String id);
	public Cart getProductsUsingProductIdAndUserId(String productId,String userSessionId);
	

}
