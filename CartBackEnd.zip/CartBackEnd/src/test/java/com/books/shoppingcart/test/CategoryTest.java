package com.books.shoppingcart.test;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.books.shoppingcart.dao.CategoryDAO;
import com.books.shoppingcart.model.Category;

public class CategoryTest {
public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context  = new AnnotationConfigApplicationContext();
		context.scan("com.books.*");
		context.refresh();
		
		Category category = (Category) context.getBean("category");
	
	    CategoryDAO categoryDAO = (CategoryDAO)  context.getBean("categoryDAO");
	    
	    
	    category.setId("C101");
        category.setName("Thriller");
        category.setDescription("Books that keep you on edge");

       
        categoryDAO.saveorUpdate(category);
       



}


}