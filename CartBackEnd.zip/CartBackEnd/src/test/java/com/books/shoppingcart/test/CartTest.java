package com.books.shoppingcart.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.books.shoppingcart.dao.CartDAO;
import com.books.shoppingcart.model.Cart;

public class CartTest {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.books.*");
		context.refresh();
		
		Cart ct =(Cart) context.getBean("cart");
		CartDAO cartDAO = (CartDAO) context.getBean("cartDAO");
		
		
//		ct.setid(1);
		ct.setPrice("300");
		ct.setProductId("nathns");
		ct.setQuantity(1);
		ct.setStatus('N');
		ct.setSessionUserId("999");
		cartDAO.saveOrUpdate(ct);
		
		/*ct.setId("U101");
		ct.setPrice("400");
		ct.setProductName("The Raven King");
		ct.setQuantity(1);
		ct.setStatus('N');
		cartDAO.saveorUpdate(ct);*/
}
}